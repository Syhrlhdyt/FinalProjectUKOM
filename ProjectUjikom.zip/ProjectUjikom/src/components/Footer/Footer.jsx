import React from 'react'
import './Footer.css'

const Footer = () => {
  return (
    <footer>
        <ul className="social-icon">
          <li><a href=""></a></li>
          <li><a href=""></a></li>
          <li><a href=""></a></li>
        </ul>
      </footer>
  )
}

export default Footer
