import React from 'react'
import './Header.css'

const Header = () => {
  return (
    <>
      <div className="home-header">
          <h1 className='home-title'>PerpusKu</h1>
          <h4 className='home-desc'>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nihil, reprehenderit!</h4>
        </div>
    </>
  )
}

export default Header
