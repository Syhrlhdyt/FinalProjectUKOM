import React from "react";
import "./Card.css";

const Card = () => {
  return (
    <>
    <h1 className='judul-content'>Kelebihan PerpusKu</h1>
    <div className="container">
      <div className="card">
        <img src="./public/images/pict1.jpg" width={300} alt="" />
        <div className="bottom">
          <h3 className="title-card">Mudah Diakses</h3>
        </div>
      </div>
      <div className="card">
        <img src="./public/images/pict2.jpg" width={300} alt="" />
        <div className="bottom">
          <h3 className="title-card">Kumpulan Buku Lengkap.</h3>
        </div>
      </div>
      <div className="card">
        <img src="./public/images/pict3.jpg" width={300} alt="" />
        <div className="bottom">
          <h3 className="title-card">Tempat paling nyaman.</h3>
        </div>
      </div>
      <div className="card">
        <img src="./public/images/pict4.jpg" width={300} alt="" />
        <div className="bottom">
          <h3 className="title-card">Kenyamanan No.1</h3>
        </div>
      </div>
      <div className="card">
        <img src="./public/images/pict5.jpg" width={300} alt="" />
        <div className="bottom">
          <h3 className="title-card">Selalu menjaga kebersihan.</h3>
        </div>
      </div>

      <div className="content-perpus">
        <h1 className="judul-perpus">Manfaat PerpusKu</h1>
        <img src="./public/images/pict1.jpg" alt=""  width={500}/>
        <div className="desk-content">
          <ol>
            <li className="item">Membuka Wawasan Baru</li>
            <li className="item">Menambahkan Pengetahuan Baru</li>
            <li className="item">Menambahkan Minat Membaca</li>
            <li className="item">Menggali Informasi Yang Lebih Luas</li>
          </ol>
        </div>
      </div>
    </div>
    </>
  );
};

export default Card;
