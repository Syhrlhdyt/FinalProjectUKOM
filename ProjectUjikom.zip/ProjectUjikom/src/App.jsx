import { useState } from "react";
import "./App.css";
import Login  from "./pages/Login/Login";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Home from "./pages/Home/Home";
import Contact from "./pages/Contact/Contact";
import Library from "./pages/Library/Library";

function App() {
  const username = localStorage.getItem("username")
  
  const logout = () => {
    localStorage.clear()
    window.location.reload()
  }
  return (
    <>
       <BrowserRouter>
       {username && 
       <header className="header">
          <a href="/" className="logo">
            PerpusKu<span class="material-symbols-outlined"></span>
          </a>
          <nav className="navbar">
            <a href="/">Home</a>
            <a href="/library">Library</a>
            <a href="/contact">Contact</a>
            {username ? <button onClick={logout} className="btn-nav">Logout<i class="fa-solid fa-right-to-bracket"></i>  </button> :
            <a href="/login">Login<i class="fa-solid fa-right-to-bracket"></i>  </a>
            }
          </nav>
        </header>
      }
        <Routes>
        {username ?<> //Jika value username terisi atau sudah melakukan login
          <Route index element={<Home />} />
          <Route path="library" element={<Library />} />
          <Route path="contact" element={<Contact />} />
        </> :
        <>
        //Jika value username kosong atau belum melakukan login
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<Login />} />
          <Route path="*" element={<Navigate to={"/"}></Navigate>}></Route>
        </>
        }
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
