import React from 'react';
import "./Contact.css"

const Contact = () => {
    return (
        <>
        <div className="home-contact">
          <h1 className='home-title'>Hubungi Kami</h1>
          <h4 className='home-desc'>Hubungi Kami Jika Anda Membutuhkan Sesuatu</h4>
        </div>
            <section className="contact">
                <form action="#">
                    <div className="input-box">
                        <div className="input-field field">
                            <input type="text" placeholder='Full Name' id='name'
                            className='item' autoComplete='off' />
                        </div>
                        <div className="input-field field">
                            <input type="text" placeholder='Email Address' id='email'
                            className='item' autoComplete='off' />
                        </div>
                    </div>

                    <div className="input-box">
                        <div className="input-field field">
                            <input type="text" placeholder='Phone Number' id='phone'
                            className='item' autoComplete='off' />
                        </div>
                        <div className="input-field field">
                            <input type="text" placeholder='Subject' id='subject'
                            className='item' autoComplete='off' />
                        </div>
                    </div>

                    <div className="textarea-field field">
                        <textarea name="" id="message" cols="30" rows="10" placeholder='Your Message' className='item'
                        autoComplete='off'></textarea>
                    </div>

                     <button type='submit'>Send Message</button>
                </form>
            </section>
        </>
    );
}

export default Contact;
