import React, { useState } from "react";
import "./Login.css";
import { useNavigate } from "react-router-dom";

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = (event) => {
    event.preventDefault();
    //digunakan ketika user menekan tombol submit maka halaman tidak akan direfresh

    if (username === "user" && password === "user") {
      localStorage.setItem("username", username);
      navigate("/");
      window.location.reload();
    } else {
      setError("Invalid username or password!");
    }
  };
  return (
    <>
      <section>
        <div className="wrapper">
          <form onSubmit={handleLogin}>
            <h1>Login</h1>
            <div className="input-login">
              <label htmlFor="username" className="label-input">
                Username
              </label>
              <input
                type="text"
                id="username"
                name="username"
                placeholder="Enter Username"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
              <i class="fa-solid fa-user"></i>
            </div>
            <div className="input-login">
              <label htmlFor="password" className="label-input">
                Password
              </label>
              <input
                type="password"
                id="password"
                name="password"
                placeholder="Enter Password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <i class="fa-solid fa-lock"></i>
            </div>

            <div className="remember-forgot">
              <label>
                <input type="checkbox" />
                Remember Me
              </label>
              <a href="">Forgot Password</a>
            </div>
            {error && <p className="error">{error}</p>}
            <button type="submit" className="btn-login">
              Login
            </button>

            <div className="register-link">
              <p>
                Don't have an Account? <a href="">Register!</a>
              </p>
            </div>
          </form>
        </div>
      </section>
    </>
  );
}

export default Login;
